extends Control




func _on_buffalo_bisons_pressed() -> void:
	TeamLibrary.selectedteam = TeamLibrary.team_stats.Buffalo_Bisons
	get_tree().change_scene_to_file("res://menus/TeamScreen.tscn")
func _on_dallas_radboys_pressed() -> void:
	TeamLibrary.selectedteam = TeamLibrary.team_stats.Dallas_Radboys
	get_tree().change_scene_to_file("res://menus/TeamScreen.tscn")
func _on_kansas_weifs_pressed() -> void:
	TeamLibrary.selectedteam = TeamLibrary.team_stats.Kansas_Weifs
	get_tree().change_scene_to_file("res://menus/TeamScreen.tscn")
