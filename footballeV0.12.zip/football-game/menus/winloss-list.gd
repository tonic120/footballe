extends ItemList

var checked = false

func _process(delta: float) -> void:
	if TeamLibrary.teamloss + TeamLibrary.teamwin == 17 and checked == false:
		add_item(str(TeamLibrary.teamwin) + "-" + str(TeamLibrary.teamloss))
		checked = true
	if TeamLibrary.teamloss + TeamLibrary.teamwin != 17:
		checked = false

func add_new_item(name_text):
	self.add_item(name_text)
	
