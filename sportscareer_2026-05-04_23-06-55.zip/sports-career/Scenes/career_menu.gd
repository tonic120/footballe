extends Control


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta):
	$Age.text = "Year: " + str(Globals.age) + " Week: " + str(Globals.weeks)
	$"Level Bar".value = Globals.xp
	$"Level Bar/Label".text = "Level " + str(Globals.level)
	if $"Level Bar".value == Globals.maxXp:
		Globals.xp = 0
		$"Level Bar".value = 0
		Globals.level += 1
		Globals.skillPoints +=1

func _on_week_up_pressed() -> void:
	Globals.weeks += 1
	if Globals.weeks == 52:
		Globals.weeks = 0
		Globals.age += 1
	Globals.xp += 10


func _on_button_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/Stats.tscn")
