extends Control


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$Indicator/Speed.text = "Speed: " + str(Globals.playerAttributes.Speed)
	$Indicator/ThrowPower.text = "ThrowPower: " + str(Globals.playerAttributes.ThrowPower)
	$Indicator/ThrowAccuracy.text = "ThrowAccuracy: " + str(Globals.playerAttributes.ThrowAccuracy)
	$Indicator/Catching.text = "Catching: " + str(Globals.playerAttributes.Catching)
	
	if Globals.skillPoints >= 1:
		$Indicator/Speed/Button.visible = true
		$Indicator/ThrowPower/Button2.visible = true
		$Indicator/ThrowAccuracy/Button3.visible = true
		$Indicator/Catching/Button4.visible = true
	else:
		$Indicator/Speed/Button.visible = false
		$Indicator/ThrowPower/Button2.visible = false
		$Indicator/ThrowAccuracy/Button3.visible = false
		$Indicator/Catching/Button4.visible = false


func _on_back_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/career_menu.tscn")

func _on_button_pressed() -> void:
	Globals.skillPoints -= 1
	Globals.playerAttributes.Speed += 1

func _on_button_2_pressed() -> void:
	Globals.skillPoints -= 1
	Globals.playerAttributes.ThrowPower += 1

func _on_button_3_pressed() -> void:
	Globals.skillPoints -= 1
	Globals.playerAttributes.ThrowAccuracy += 1

func _on_button_4_pressed() -> void:
	Globals.skillPoints -= 1
	Globals.playerAttributes.Catching += 1
