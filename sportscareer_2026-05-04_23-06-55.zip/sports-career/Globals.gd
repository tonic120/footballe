extends Node
var age = 16
var weeks = 0
var level = 0
var xp = 0
var maxXp = 100
var skillPoints = 0

var playerAttributes = {
	ThrowPower = 30,
	ThrowAccuracy = 30,
	Speed = 30,
	Catching = 30
}

var WeeklyPlayerStats = {
	PassingYards = 0,
}

var SeasonPlayerStats = {
	PassingYards = 0,
}

var CareerPlayerStats = {
	PassingYards = 0,
}

var localTeams = {
	"Plum Bulldogs": {"Overall": 40, "School": "Plum Highschool"},
	"Fairville Tigers": {"Overall": 55, "School": "Fairville Highschool"},
	"Louise Gators": {"Overall": 53, "School": "Louise Prep66"}
}
