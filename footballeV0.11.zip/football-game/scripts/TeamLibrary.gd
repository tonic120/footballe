extends Node

var teamwin = 0
var teamloss = 0
var selectedteam = "none"

var team_stats = {
	"Buffalo_Bisons":{"Team_Name":"Buffalo Bisons", "Team_Color":Color.hex(0x004dffff)},
	"Dallas_Radboys":{"Team_Name":"Dallas Radboys", "Team_Color":Color.hex(0x000070ff)}
}
