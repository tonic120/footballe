extends Node

var sim = false
var total_games = 0

func Sim_Game():
	var result =  ([1, 0].pick_random())
	if result == 1:
		TeamLibrary.teamwin += 1
	else:
		TeamLibrary.teamloss += 1
	if total_games == 18:
		TeamLibrary.teamloss = 0
		TeamLibrary.teamwin = 0
		total_games = 0
	update_score()
func update_score():
	$Label.text = str(TeamLibrary.teamwin) + "-" + str(TeamLibrary.teamloss)

func _ready():
	$TeamName.text = TeamLibrary.selectedteam.Team_Name
	$TeamName.label_settings.font_color = Color(TeamLibrary.selectedteam.Team_Color)


func _on_play_button_pressed():
	if sim:
		return
	total_games += 1
	sim = true
	Sim_Game()
	await get_tree().create_timer(0.5).timeout
	sim = false


func _on_show_record_button_mouse_entered() -> void:
	$winlosslist.visible = true
func _on_show_record_button_mouse_exited() -> void:
	$winlosslist.visible = false
